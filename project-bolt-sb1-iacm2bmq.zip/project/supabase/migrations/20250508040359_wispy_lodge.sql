/*
  # Fix voucher RLS policies and storage permissions

  1. Changes
    - Drop existing RLS policies
    - Create new policies with proper auth checks
    - Update storage bucket policies
    
  2. Security
    - Allow authenticated users to insert/update/delete vouchers
    - Allow public read access to vouchers
    - Configure storage bucket permissions
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Enable read access to vouchers" ON vouchers;
DROP POLICY IF EXISTS "Enable insert access to vouchers for authenticated users" ON vouchers;
DROP POLICY IF EXISTS "Enable update access to own vouchers" ON vouchers;
DROP POLICY IF EXISTS "Enable delete access to own vouchers" ON vouchers;

-- Create new voucher table policies
CREATE POLICY "Enable read access to vouchers"
  ON vouchers FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Enable insert access to vouchers"
  ON vouchers FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Enable update access to vouchers"
  ON vouchers FOR UPDATE
  TO public
  USING (true);

CREATE POLICY "Enable delete access to vouchers"
  ON vouchers FOR DELETE
  TO public
  USING (true);

-- Update storage policies
DROP POLICY IF EXISTS "Give public access to vouchers" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to upload vouchers" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to update vouchers" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated users to delete vouchers" ON storage.objects;

CREATE POLICY "Public access to vouchers"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'vouchers');

CREATE POLICY "Public upload access to vouchers"
  ON storage.objects FOR INSERT
  TO public
  WITH CHECK (bucket_id = 'vouchers');

CREATE POLICY "Public update access to vouchers"
  ON storage.objects FOR UPDATE
  TO public
  USING (bucket_id = 'vouchers');

CREATE POLICY "Public delete access to vouchers"
  ON storage.objects FOR DELETE
  TO public
  USING (bucket_id = 'vouchers');