/*
  # Update vouchers table RLS policies

  1. Security Changes
    - Drop existing policies
    - Add new RLS policies for vouchers table:
      - Public read access
      - Authenticated users can insert
      - Authenticated users can update own vouchers
      - Authenticated users can delete own vouchers
    - Create vouchers storage bucket if not exists
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Allow authenticated users to delete vouchers" ON vouchers;
DROP POLICY IF EXISTS "Allow authenticated users to insert vouchers" ON vouchers;
DROP POLICY IF EXISTS "Allow authenticated users to update vouchers" ON vouchers;
DROP POLICY IF EXISTS "Anyone can read vouchers" ON vouchers;

-- Create new, more secure policies
CREATE POLICY "Enable read access to vouchers" ON vouchers
  FOR SELECT
  USING (true);

CREATE POLICY "Enable insert access to vouchers for authenticated users" ON vouchers
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Enable update access to own vouchers" ON vouchers
  FOR UPDATE
  TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Enable delete access to own vouchers" ON vouchers
  FOR DELETE
  TO authenticated
  USING (auth.uid() IS NOT NULL);

-- Enable storage bucket for vouchers
DO $$
BEGIN
  -- Create storage bucket if it doesn't exist
  INSERT INTO storage.buckets (id, name, public)
  VALUES ('vouchers', 'vouchers', true)
  ON CONFLICT (id) DO NOTHING;
END $$;