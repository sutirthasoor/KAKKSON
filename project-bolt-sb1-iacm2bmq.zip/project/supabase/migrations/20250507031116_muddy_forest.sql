/*
  # Fix voucher table RLS policies

  1. Changes
    - Add RLS policy to allow authenticated users to insert vouchers
    - Add RLS policy to allow authenticated users to update their vouchers
    - Add RLS policy to allow authenticated users to delete their vouchers
  
  2. Security
    - Maintains existing read policy
    - Adds secure write policies for authenticated users
*/

-- Add policy for inserting vouchers
CREATE POLICY "Allow authenticated users to insert vouchers"
  ON vouchers
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Add policy for updating vouchers
CREATE POLICY "Allow authenticated users to update vouchers"
  ON vouchers
  FOR UPDATE
  TO authenticated
  USING (true);

-- Add policy for deleting vouchers
CREATE POLICY "Allow authenticated users to delete vouchers"
  ON vouchers
  FOR DELETE
  TO authenticated
  USING (true);