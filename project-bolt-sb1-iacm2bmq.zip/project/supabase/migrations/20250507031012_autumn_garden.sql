/*
  # Create storage bucket for vouchers

  1. New Storage
    - Creates a new storage bucket named 'vouchers' for storing PDF vouchers
  
  2. Security
    - Enables public access for reading vouchers
    - Restricts upload/delete operations to authenticated users only
*/

-- Create the storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('vouchers', 'vouchers', true);

-- Policy to allow public access to read vouchers
CREATE POLICY "Give public access to vouchers"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'vouchers');

-- Policy to allow authenticated users to upload vouchers
CREATE POLICY "Allow authenticated users to upload vouchers"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'vouchers');

-- Policy to allow authenticated users to update their vouchers
CREATE POLICY "Allow authenticated users to update vouchers"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'vouchers');

-- Policy to allow authenticated users to delete their vouchers
CREATE POLICY "Allow authenticated users to delete vouchers"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'vouchers');