/*
  # Create vouchers table and storage bucket

  1. New Tables
    - `vouchers`
      - `id` (uuid, primary key)
      - `booking_id` (text, references booking ID)
      - `file_path` (text, stores the path in storage)
      - `created_at` (timestamp)
      
  2. Security
    - Enable RLS on `vouchers` table
    - Add policy for authenticated users to read vouchers
*/

CREATE TABLE IF NOT EXISTS vouchers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id text NOT NULL,
  file_path text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE vouchers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read vouchers"
  ON vouchers
  FOR SELECT
  TO public
  USING (true);