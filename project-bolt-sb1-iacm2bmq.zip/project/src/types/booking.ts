export interface Guest {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  country: string;
  postalCode: string;
}

export interface BookingDetails {
  hotel: string;
  checkIn: string;
  checkOut: string;
  adults: number;
  children: number;
  roomType: string;
  numberOfRooms: number;
  specialRequests?: string;
  paymentMethod: string;
  tariff: string;
  advance: string;
  mealPlan: string;
  checkInTime: string;
  checkOutTime: string;
}

export interface Booking {
  id: string;
  guest: Guest;
  booking: BookingDetails;
  totalPrice: number;
  bookingDate: string;
  status: 'confirmed' | 'pending' | 'cancelled';
  voucherSent: boolean;
}

export type BookingFormData = {
  guest: Guest;
  booking: BookingDetails;
};