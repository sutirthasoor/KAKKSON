import { create } from 'zustand';
import { Booking } from '../types/booking';

interface BookingStore {
  bookings: Booking[];
  currentBooking: Booking | null;
  setCurrentBooking: (booking: Booking) => void;
  setBookings: (bookings: Booking[]) => void;
  addBooking: (booking: Booking) => void;
  updateBookingStatus: (id: string, status: Booking['status']) => void;
  setVoucherSent: (id: string, sent: boolean) => void;
}

const useBookingStore = create<BookingStore>((set) => ({
  bookings: [],
  currentBooking: null,
  
  setCurrentBooking: (booking) => set({ currentBooking: booking }),
  
  setBookings: (bookings) => set({ bookings }),
  
  addBooking: (booking) => set((state) => ({
    bookings: [...state.bookings, booking],
    currentBooking: booking
  })),
  
  updateBookingStatus: (id, status) => set((state) => ({
    bookings: state.bookings.map(booking => 
      booking.id === id ? { ...booking, status } : booking
    ),
    currentBooking: state.currentBooking?.id === id 
      ? { ...state.currentBooking, status } 
      : state.currentBooking
  })),
  
  setVoucherSent: (id, sent) => set((state) => ({
    bookings: state.bookings.map(booking => 
      booking.id === id ? { ...booking, voucherSent: sent } : booking
    ),
    currentBooking: state.currentBooking?.id === id 
      ? { ...state.currentBooking, voucherSent: sent } 
      : state.currentBooking
  })),
}));

export default useBookingStore;