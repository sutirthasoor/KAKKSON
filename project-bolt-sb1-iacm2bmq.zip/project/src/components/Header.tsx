import { Link } from 'react-router-dom';
import { Building2, Menu, X } from 'lucide-react';
import { useState } from 'react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-elegant sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2">
          <Building2 className="h-8 w-8 text-primary" />
          <span className="font-serif text-2xl font-medium">KAKKSON GROUP</span>
        </Link>
        
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li>
              <Link to="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
            </li>
            <li>
              <Link to="/booking" className="text-foreground hover:text-primary transition-colors">
                Book Now
              </Link>
            </li>
            <li>
              <Link to="/admin" className="text-foreground hover:text-primary transition-colors">
                Admin
              </Link>
            </li>
          </ul>
        </nav>
        
        <button 
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? (
            <X className="h-6 w-6 text-foreground" />
          ) : (
            <Menu className="h-6 w-6 text-foreground" />
          )}
        </button>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <ul className="flex flex-col py-4">
            <li>
              <Link 
                to="/" 
                className="block px-4 py-2 text-foreground hover:bg-muted"
                onClick={() => setIsMenuOpen(false)}
              >
                Home
              </Link>
            </li>
            <li>
              <Link 
                to="/booking" 
                className="block px-4 py-2 text-foreground hover:bg-muted"
                onClick={() => setIsMenuOpen(false)}
              >
                Book Now
              </Link>
            </li>
            <li>
              <Link 
                to="/admin" 
                className="block px-4 py-2 text-foreground hover:bg-muted"
                onClick={() => setIsMenuOpen(false)}
              >
                Admin
              </Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
};

export default Header;