import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-foreground text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-serif text-xl mb-4">KAKKSON GROUP</h3>
            <p className="text-gray-300 mb-4">
              Experience unparalleled comfort and premium stays at our prestigious hotels. Book your stay with us and create memories that last a lifetime.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-secondary transition-colors">
                <Twitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-serif text-xl mb-4">Our Hotels</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <h4 className="font-medium mb-2">KAKKSON VILLA</h4>
                <p className="text-sm text-gray-300">Semi Deluxe to Luxury Four Bedded AC rooms</p>
              </div>
              <div>
                <h4 className="font-medium mb-2">KAKKSON INN</h4>
                <p className="text-sm text-gray-300">Executive rooms with AC and Non-AC options</p>
              </div>
              <div>
                <h4 className="font-medium mb-2">KAKKSON CLUB</h4>
                <p className="text-sm text-gray-300">Premium suites with Jacuzzi options</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6">
          <p className="text-gray-400 text-center text-sm">
            &copy; {new Date().getFullYear()} KAKKSON GROUP. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;