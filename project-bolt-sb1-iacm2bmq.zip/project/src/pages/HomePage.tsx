import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, UserCheck, Clock, Check } from 'lucide-react';
import Button from '../components/ui/Button';

const HomePage = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');

  const correctPassword = '1290'; // Change this to your desired 4-digit code

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === correctPassword) {
      setIsAuthenticated(true);
    } else {
      alert('Incorrect password');
    }
  };

  return (
    <div className="flex flex-col relative">
      {/* 🔐 Login Modal Overlay */}
      {!isAuthenticated && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-70 flex items-center justify-center">
          <form
            onSubmit={handleLogin}
            className="bg-white p-6 rounded-xl shadow-xl w-[90%] max-w-sm text-center"
          >
            <h2 className="text-xl font-semibold mb-4">Enter 4-Digit Access Code</h2>
            <input
              type="password"
              maxLength={4}
              pattern="\d{4}"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              className="w-full p-2 border rounded mb-4 text-center text-xl tracking-widest"
              placeholder="••••"
              required
            />
            <button
              type="submit"
              className="bg-black text-white px-6 py-2 rounded hover:bg-gray-800"
            >
              Enter
            </button>
          </form>
        </div>
      )}

      {/* ✅ Website Content Only If Authenticated */}
      {isAuthenticated && (
        <>
          {/* Hero Section */}
          <div className="relative h-[70vh] flex items-center justify-center overflow-hidden">
            <div 
              className="absolute inset-0 bg-cover bg-center" 
              style={{ 
                backgroundImage: "url('https://i.postimg.cc/rw3Q9yqT/kason-logo.jpg')",
                filter: "brightness(0.6)"
              }}
            ></div>
            <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
              <h1 className="font-serif text-4xl md:text-6xl text-white mb-4">Welcome to KAKKSON GROUP</h1>
              <p className="text-xl text-gray-200 mb-8">Experience luxury and comfort across our premium hotels</p>
              <Link to="/booking">
                <Button>Book Now</Button>
              </Link>
            </div>
          </div>

          {/* Features Section */}
          <div className="py-16 bg-white">
            <div className="container mx-auto px-4">
              <h2 className="font-serif text-3xl text-center mb-12">Why Choose KAKKSON GROUP</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="bg-muted rounded-lg p-6 text-center shadow-elegant transition-all hover:shadow-elegant-lg hover:-translate-y-1">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                    <Calendar size={24} />
                  </div>
                  <h3 className="font-medium text-lg mb-2">Easy Booking</h3>
                  <p className="text-muted-foreground">Simple and secure online booking process with instant confirmation.</p>
                </div>

                <div className="bg-muted rounded-lg p-6 text-center shadow-elegant transition-all hover:shadow-elegant-lg hover:-translate-y-1">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                    <UserCheck size={24} />
                  </div>
                  <h3 className="font-medium text-lg mb-2">Personalized Service</h3>
                  <p className="text-muted-foreground">Tailored experiences to meet your unique preferences and requirements.</p>
                </div>

                <div className="bg-muted rounded-lg p-6 text-center shadow-elegant transition-all hover:shadow-elegant-lg hover:-translate-y-1">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                    <Clock size={24} />
                  </div>
                  <h3 className="font-medium text-lg mb-2">24/7 Support</h3>
                  <p className="text-muted-foreground">Round-the-clock assistance to ensure your stay is comfortable and worry-free.</p>
                </div>

                <div className="bg-muted rounded-lg p-6 text-center shadow-elegant transition-all hover:shadow-elegant-lg hover:-translate-y-1">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary mb-4">
                    <Check size={24} />
                  </div>
                  <h3 className="font-medium text-lg mb-2">Best Rate Guarantee</h3>
                  <p className="text-muted-foreground">We promise you'll get the best available rate when booking directly with us.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Hotels Preview */}
          <div className="py-16 bg-muted">
            <div className="container mx-auto px-4">
              <h2 className="font-serif text-3xl text-center mb-4">Our Premium Hotels</h2>
              <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
                Choose from our selection of premium hotels, each offering unique experiences and comfortable stays.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Kakkson Villa */}
                <div className="rounded-lg overflow-hidden shadow-elegant group">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src="https://i.postimg.cc/prdPJJBp/LUXURY-AC-FOUR-BEDDED.jpg" 
                      alt="Hotel KV" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-6 bg-white">
                    <h3 className="font-serif text-xl mb-2">KAKKSON VILLA</h3>
                    <p className="text-muted-foreground mb-4">Experience comfort with our range of rooms from Semi Deluxe to Luxury Four Bedded AC.</p>
                    <div className="flex justify-between items-center">
                      <Link to="/booking">
                        <Button>Book Now</Button>
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Kakkson Inn */}
                <div className="rounded-lg overflow-hidden shadow-elegant group">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src="https://i.postimg.cc/tg9w6Ckg/EXECUTIVE-FOUR-BEDDED.jpg" 
                      alt="Hotel KINN" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-6 bg-white">
                    <h3 className="font-serif text-xl mb-2">KAKKSON INN</h3>
                    <p className="text-muted-foreground mb-4">Choose from our Executive rooms with AC and Non-AC options.</p>
                    <div className="flex justify-between items-center">
                      <Link to="/booking">
                        <Button>Book Now</Button>
                      </Link>
                    </div>
                  </div>
                </div>

                {/* Kakkson Club */}
                <div className="rounded-lg overflow-hidden shadow-elegant group">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src="https://i.postimg.cc/7LXcn8tn/PREMIUM-SUITE.jpg" 
                      alt="Hotel KC" 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                  </div>
                  <div className="p-6 bg-white">
                    <h3 className="font-serif text-xl mb-2">KAKKSON CLUB</h3>
                    <p className="text-muted-foreground mb-4">Luxury suites including Premium Double, Suite, and Jacuzzi options.</p>
                    <div className="flex justify-between items-center">
                      <Link to="/booking">
                        <Button>Book Now</Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="py-16 bg-foreground text-white">
            <div className="container mx-auto px-4 text-center">
              <h2 className="font-serif text-3xl mb-4">Ready to Experience Premium Comfort?</h2>
              <p className="mb-8 max-w-2xl mx-auto">
                Book your stay with KAKKSON GROUP today and experience the perfect blend of luxury, comfort, and impeccable service.
              </p>
              <Link to="/booking">
                <Button variant="outline" className="text-white border-white hover:bg-white hover:text-black">
                  Book Now
                </Button>
              </Link>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default HomePage;
