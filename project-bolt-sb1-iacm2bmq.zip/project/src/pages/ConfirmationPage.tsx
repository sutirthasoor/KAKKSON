import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Check, Download, Phone } from 'lucide-react';
import useBookingStore from '../store/bookingStore';
import Button from '../components/ui/Button';
import { formatCurrency } from '../lib/utils';
import { downloadVoucher, sendVoucher } from '../utils/sendVoucher';

const ConfirmationPage = () => {
  const navigate = useNavigate();
  const { currentBooking } = useBookingStore();
  const [voucherSent, setVoucherSent] = useState(false);
  const [sending, setSending] = useState(false);
  
  useEffect(() => {
    // Redirect if no booking is available
    if (!currentBooking) {
      navigate('/booking');
    }
  }, [currentBooking, navigate]);
  
  if (!currentBooking) {
    return null;
  }
  
  const handleSendVoucher = async () => {
    setSending(true);
    const success = await sendVoucher(currentBooking);
    setSending(false);
    if (success) {
      setVoucherSent(true);
    }
  };
  
  const handleDownloadVoucher = async () => {
    await downloadVoucher(currentBooking);
  };
  
  return (
    <div className="py-12 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-elegant p-6 md:p-8">
          <div className="flex flex-col items-center mb-8 text-center">
            <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mb-4">
              <Check className="w-8 h-8 text-white" />
            </div>
            <h1 className="font-serif text-3xl">Booking Confirmed!</h1>
            <p className="text-muted-foreground mt-2">Your booking has been successfully confirmed. Thank you for choosing Kakkson Group Of Hotels.</p>
          </div>
          
          <div className="mb-8">
            <h2 className="font-serif text-xl mb-4 border-b pb-2">Booking Details</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Booking Date</p>
                <p className="font-medium">{format(new Date(currentBooking.bookingDate), 'MMM dd, yyyy')}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Check-in</p>
                <p className="font-medium">{format(new Date(currentBooking.booking.checkIn), 'MMM dd, yyyy')}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Check-out</p>
                <p className="font-medium">{format(new Date(currentBooking.booking.checkOut), 'MMM dd, yyyy')}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Room Type</p>
                <p className="font-medium">
                  {currentBooking.booking.roomType === 'deluxe' && 'Deluxe Room'}
                  {currentBooking.booking.roomType === 'executive' && 'Executive Suite'}
                  {currentBooking.booking.roomType === 'presidential' && 'Presidential Suite'}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Guests</p>
                <p className="font-medium">{currentBooking.booking.adults} Adult(s), {currentBooking.booking.children} Child(ren)</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Payment Method</p>
                <p className="font-medium">
                  {currentBooking.booking.paymentMethod === 'cash' && 'Cash'}
                  {currentBooking.booking.paymentMethod === 'upi' && 'Upi'}
                  {currentBooking.booking.paymentMethod === 'card' && 'Card'}
                  {currentBooking.booking.paymentMethod === 'acc' && 'Acc'}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Amount</p>
                <p className="font-medium">{formatCurrency(currentBooking.totalPrice)}</p>
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <h2 className="font-serif text-xl mb-4 border-b pb-2">Guest Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="font-medium">{currentBooking.guest.firstName} {currentBooking.guest.lastName}</p>
              </div>
              <div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Phone</p>
                <p className="font-medium">{currentBooking.guest.phone}</p>
              </div>
              <div>
              </div>
              <div>
              </div>
              <div>
              </div>
            </div>
          </div>
          
          <div className="bg-primary/10 rounded-lg p-6 mb-8">
            <h2 className="font-serif text-xl mb-2">Booking Voucher</h2>
            <p className="mb-4">You can download your booking voucher or send it via WhatsApp.</p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
              <Button onClick={handleDownloadVoucher} className="flex items-center justify-center gap-2">
                <Download size={18} />
                Download Voucher
              </Button>
               
            
              
              <Button 
                variant="secondary"
                onClick={handleSendVoucher}
                disabled={voucherSent || sending}
                className="flex items-center justify-center gap-2"
              >
                {sending ? (
                  "Sending..."
                ) : voucherSent ? (
                  <>
                    <Check size={18} />
                    Voucher Sent
                  </>
                ) : (
                  <>
                    <Phone size={18} />
                    Send via WhatsApp
                  </>
                )}
              </Button>
            </div>
          </div>
          
          <div className="text-center">
            <Button variant="outline" onClick={() => navigate('/')}>
              Return to Home Page
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationPage;