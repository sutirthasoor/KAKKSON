import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { differenceInDays, format, addDays } from 'date-fns';
import { BookingFormData, Booking } from '../types/booking';
import useBookingStore from '../store/bookingStore';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import { formatCurrency } from '../lib/utils';
import { supabase } from '../utils/supabase';

const bookingSchema = z.object({
  guest: z.object({
    firstName: z.string().min(2, 'First name is required'),
    lastName: z.string().min(2, 'Last name is required'),
    phone: z.string().min(10, 'Valid phone number is required'),
  }),
  booking: z.object({
    hotel: z.string().min(1, 'Hotel selection is required'),
    checkIn: z.string().min(1, 'Check-in date is required'),
    checkInTime: z.string().min(1, 'Check-in time is required'),
    checkOutTime: z.string().min(1, 'Check-in time is required'),    
    tariff: z.string().min(1, 'Tariff is required'),
    advance: z.string().min(1, 'Advance is required'),
    checkOut: z.string().min(1, 'Check-out date is required'),
    adults: z.number().min(1, 'At least 1 adult is required'),
    children: z.number().min(0),
    numberOfRooms: z.number().min(1, 'At least 1 room is required'),
    roomType: z.string().min(1, 'Room type is required'),
    mealPlan: z.string().min(1, 'Meal plan is required'),
    specialRequests: z.string().optional(),
    paymentMethod: z.string().min(1, 'Payment method is required'),
  }),
});

const hotels = {
  'KAKKSON VILLA': {
    name: 'KAKKSON VILLA',
    rooms: {
      'semi-deluxe-non-ac': { name: 'Semi Deluxe Non AC'},
      'deluxe-ac': { name: 'Deluxe AC'},
      'luxury-ac': { name: 'Luxury AC'},
      'luxury-four-bedded-ac': { name: 'Luxury Four Bedded AC' },
    },
  },
  'KAKKSON INN': {
    name: 'KAKKSON INN',
    rooms: {
      'executive-non-ac': { name: 'Executive Non AC'  },
      'executive-ac': { name: 'Executive AC'  },
      'executive-four-bedded-ac': { name: 'Executive Four Bedded AC' },
    },
  },
  'KAKKSON CLUB': {
    name: 'KAKKSON CLUB',
    rooms: {
      'premium-double': { name: 'Premium Double' },
      'premium-suite': { name: 'Premium Suite' },
      'jacuzzi-suite': { name: 'Jacuzzi Suite' },
    },
  },
};

const BookingPage = () => {
  const [step, setStep] = useState(1);
  const [totalPrice, setTotalPrice] = useState(0);
  const [selectedHotel, setSelectedHotel] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { addBooking } = useBookingStore();
  
  const {
    register,
    handleSubmit,
    watch,
    trigger,
    formState: { errors },
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    mode: 'onChange',
    defaultValues: {
      guest: {
        firstName: '',
        lastName: '',
        phone: '',
      },
      booking: {
        hotel: '',
        checkIn: format(new Date(), 'yyyy-MM-dd'),
        checkOut: format(addDays(new Date(), 1), 'yyyy-MM-dd'),
        adults: 1,
        children: 0,
        numberOfRooms: 1,
        roomType: '',
        specialRequests: '',
        paymentMethod: '',
        tariff: '',
        advance: '',
        mealPlan: '',
        checkInTime: '',
        checkOutTime: '',
      },
    },
  });
  
  const watchedValues = watch();
  
  const calculatePrice = () => {
    const { checkIn, checkOut, hotel, roomType, numberOfRooms } = watchedValues.booking;
    
    if (!checkIn || !checkOut || !hotel || !roomType) return 0;
    
    const checkInDate = new Date(checkIn);
    const checkOutDate = new Date(checkOut);
    const nights = Math.max(1, differenceInDays(checkOutDate, checkInDate));
    
    const selectedHotelRooms = hotels[hotel as keyof typeof hotels]?.rooms;
    const basePrice = selectedHotelRooms?.[roomType as keyof typeof selectedHotelRooms]?.price || 0;
    
    return basePrice * nights * numberOfRooms;
  };
  
  useState(() => {
    setTotalPrice(calculatePrice());
  });
  
  const handleHotelChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedHotel(e.target.value);
    register('booking.hotel').onChange(e);
  };
  
  const nextStep = async () => {
    const isStepValid = await trigger(step === 1 ? 'guest' : 'booking');
    
    if (isStepValid) {
      if (step === 1) {
        setStep(2);
      } else {
        const price = calculatePrice();
        setTotalPrice(price);
      }
    }
  };
  
  const prevStep = () => {
    setStep(1);
  };
  
  const onSubmit: SubmitHandler<BookingFormData> = (data) => {
    setIsSubmitting(true);
    
    try {
      const bookingId = `BK-${Date.now().toString().slice(-6)}`;
      
      // Insert booking into Supabase
      const { error } = await supabase
        .from('bookings')
        .insert({
          id: bookingId,
          guest_first_name: data.guest.firstName,
          guest_last_name: data.guest.lastName,
          guest_phone: data.guest.phone,
          hotel: data.booking.hotel,
          room_type: data.booking.roomType,
          number_of_rooms: data.booking.numberOfRooms,
          adults: data.booking.adults,
          children: data.booking.children,
          check_in_date: data.booking.checkIn,
          check_out_date: data.booking.checkOut,
          check_in_time: data.booking.checkInTime || '',
          check_out_time: data.booking.checkOutTime || '',
          meal_plan: data.booking.mealPlan,
          tariff: data.booking.tariff,
          advance: data.booking.advance,
          payment_method: data.booking.paymentMethod,
          special_requests: data.booking.specialRequests || '',
          status: 'confirmed',
          voucher_sent: false
        });

      if (error) {
        console.error('Error saving booking:', error);
        alert('Error saving booking. Please try again.');
        return;
      }

      // Create booking object for local state
      const newBooking: Booking = {
        id: bookingId,
        guest: data.guest,
        booking: data.booking,
        totalPrice,
        bookingDate: new Date().toISOString(),
        status: 'confirmed',
        voucherSent: false,
      };
      
      addBooking(newBooking);
      navigate('/confirmation');
    } catch (error) {
      console.error('Error submitting booking:', error);
      alert('Error submitting booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="py-12 bg-muted">
      <div className="container mx-auto px-4">
        <h1 className="font-serif text-3xl text-center mb-8">Book Your Stay</h1>
        
        <div className="max-w-3xl mx-auto mb-8">
          <div className="flex justify-between">
            <div className="text-center">
              <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center ${step >= 1 ? 'bg-primary text-white' : 'bg-muted-foreground text-white'}`}>
                1
              </div>
              <div className="mt-2 text-sm">Guest Information</div>
            </div>
            <div className="hidden sm:block w-full flex-1 mt-5">
              <div className={`h-1 ${step >= 2 ? 'bg-primary' : 'bg-muted-foreground'}`}></div>
            </div>
            <div className="text-center">
              <div className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center ${step >= 2 ? 'bg-primary text-white' : 'bg-muted-foreground text-white'}`}>
                2
              </div>
              <div className="mt-2 text-sm">Booking Details</div>
            </div>
          </div>
        </div>
        
        <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-elegant p-6 md:p-8">
          <form onSubmit={handleSubmit(onSubmit)}>
            {step === 1 && (
              <div className="space-y-6 form-animation">
                <h2 className="font-serif text-2xl mb-6">Guest Information</h2>
                
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="First Name"
                    {...register('guest.firstName')}
                    error={errors.guest?.firstName?.message}
                  />
                  
                  <Input
                    label="Last Name"
                    {...register('guest.lastName')}
                    error={errors.guest?.lastName?.message}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Phone Number"
                    {...register('guest.phone')}
                    error={errors.guest?.phone?.message}
                  />
                </div>
                
                <div className="pt-4 flex justify-end">
                  <Button type="button" onClick={nextStep}>
                    Continue to Booking Details
                  </Button>
                </div>
              </div>
            )}
            
            {step === 2 && (
              <div className="space-y-6 form-animation">
                <h2 className="font-serif text-2xl mb-6">Booking Details</h2>
                
                <Select
                  label="Select Hotel"
                  {...register('booking.hotel')}
                  error={errors.booking?.hotel?.message}
                  onChange={handleHotelChange}
                  options={[
                    { value: 'KAKKSON VILLA', label: 'KAKKSON VILLA' },
                    { value: 'KAKKSON INN', label: 'KAKKSON INN' },
                    { value: 'KAKKSON CLUB', label: 'KAKKSON CLUB' },
                  ]}
                />
                
                {selectedHotel && (
                  <Select
                    label="Room Type"
                    {...register('booking.roomType')}
                    error={errors.booking?.roomType?.message}
                    options={Object.entries(hotels[selectedHotel as keyof typeof hotels].rooms).map(([value, room]) => ({
                      value,
                      label: `${room.name}`,
                    }))}
                    onChange={(e) => {
                      register('booking.roomType').onChange(e);
                      setTotalPrice(calculatePrice());
                    }}
                  />
                )}

                <Select
                  label="Meal Plan"
                  {...register('booking.mealPlan')}
                  error={errors.booking?.mealPlan?.message}
                  options={[
                    { value: 'EP', label: 'EP (Room Only)' },
                    { value: 'CP', label: 'CP (Room + Breakfast)' },
                    { value: 'MAP', label: 'MAP (Room + Breakfast + Dinner)' },
                    { value: 'AP', label: 'AP (Room + All Meals)' },
                  ]}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Input
                    label="Check-in Date"
                    type="date"
                    {...register('booking.checkIn')}
                    error={errors.booking?.checkIn?.message}
                    min={format(new Date(), 'yyyy-MM-dd')}
                    onChange={(e) => {
                      register('booking.checkIn').onChange(e);
                      setTotalPrice(calculatePrice());
                    }}
                  />
                  
                  <Input
                    label="Check-out Date"
                    type="date"
                    {...register('booking.checkOut')}
                    error={errors.booking?.checkOut?.message}
                    min={format(addDays(new Date(watchedValues.booking.checkIn || new Date()), 1), 'yyyy-MM-dd')}
                    onChange={(e) => {
                      register('booking.checkOut').onChange(e);
                      setTotalPrice(calculatePrice());
                    }}
                  />
                </div>
               
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Input
                    label="Number of Rooms"
                    type="number"
                    min="1"
                    max="10"
                    {...register('booking.numberOfRooms', { valueAsNumber: true })}
                    error={errors.booking?.numberOfRooms?.message}
                    onChange={(e) => {
                      register('booking.numberOfRooms').onChange(e);
                      setTotalPrice(calculatePrice());
                    }}
                  />
                  
                  <Input
                    label="Adults"
                    type="number"
                    min="1"
                    max="10"
                    {...register('booking.adults', { valueAsNumber: true })}
                    error={errors.booking?.adults?.message}
                  />
                  
                  <Input
                    label="Children"
                    type="number"
                    min="0"
                    max="10"
                    {...register('booking.children', { valueAsNumber: true })}
                    error={errors.booking?.children?.message}
                  />
                </div>
                
                <Select
                  label="Payment Method"
                  {...register('booking.paymentMethod')}
                  error={errors.booking?.paymentMethod?.message}
                  options={[
                    { value: 'cash', label: 'Cash' },
                    { value: 'upi', label: 'UPI' },
                    { value: 'card', label: 'Card' },
                    { value: 'acc', label: 'Account Transfer' },
                  ]}
                />
                
                <div className="space-y-2">
                  <label htmlFor="specialRequests" className="block text-sm font-medium text-foreground">
                    Special Requests (Optional)
                  </label>
                  <textarea
                    id="specialRequests"
                    rows={3}
                    className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                    placeholder="Any special requests or preferences..."
                    {...register('booking.specialRequests')}
                  ></textarea>
                </div>

                <div className="space-y-2">
                  <Input
                    label="Tariff (₹)"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Enter tariff amount"
                    {...register('booking.tariff')}
                    error={errors.booking?.tariff?.message}
                  />
                </div>

                <div className="space-y-2">
                  <Input
                    label="Advance Payment (₹)"
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="Enter advance amount"
                    {...register('booking.advance')}
                    error={errors.booking?.advance?.message}
                  />
                </div>
                
                <div className="pt-4 flex justify-between">
                  <Button type="button" variant="outline" onClick={prevStep}>
                    Back
                  </Button>
                  <Button type="submit" disabled={isSubmitting}>
                    {isSubmitting ? 'Processing...' : 'Complete Booking'}
                  </Button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};

export default BookingPage;