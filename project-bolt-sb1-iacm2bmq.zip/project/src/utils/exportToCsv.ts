import { Booking } from '../types/booking';
import { format } from 'date-fns';

export function exportBookingsToCsv(bookings: Booking[]): void {
  // Define CSV headers
  const headers = [
    'Booking ID',
    'Booking Date',
    'Guest Name',
    'Email',
    'Phone',
    'Hotel',
    'Room Type',
    'Check-in',
    'Check-out',
    'Adults',
    'Children',
    'Tariff',
    'Advance',
    'Total Price',
    'Payment Method',
    'Status'
  ];

  // Transform bookings into CSV rows
  const rows = bookings.map(booking => [
    booking.id,
    format(new Date(booking.bookingDate), 'yyyy-MM-dd'),
    `${booking.guest.firstName} ${booking.guest.lastName}`,
    booking.guest.email,
    booking.guest.phone,
    booking.booking.hotel,
    booking.booking.roomType,
    format(new Date(booking.booking.checkIn), 'yyyy-MM-dd'),
    format(new Date(booking.booking.checkOut), 'yyyy-MM-dd'),
    booking.booking.adults,
    booking.booking.children,
    booking.booking.tariff,
    booking.booking.advance,
    booking.totalPrice,
    booking.booking.paymentMethod,
    booking.status
  ]);

  // Combine headers and rows
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');

  // Create and trigger download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `bookings-${format(new Date(), 'yyyy-MM-dd')}.csv`);
  document.body.appendChild(link);
  link.click();
  
  // Cleanup
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}