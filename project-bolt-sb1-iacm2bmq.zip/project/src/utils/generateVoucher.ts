import { jsPDF } from 'jspdf';
import { Booking } from '../types/booking';
import { format } from 'date-fns';

export async function generateVoucher(booking: Booking): Promise<Blob> {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });
  
  // Set document properties
  doc.setProperties({
    title: 'Booking Voucher',
    subject: 'Hotel Booking Voucher',
    author: 'Kakkson Group Of Hotels',
    creator: 'Kakkson Group Of Hotels Booking System'
  });
  
  // Add hotel logo/header
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138); // Deep blue
  doc.text(`GREETING FROM ${booking.booking.hotel}`, 105, 20, { align: 'center' });
 
  // Add decorative line
  doc.setDrawColor(234, 179, 8); // Gold color
  doc.setLineWidth(0.5);
  doc.line(20, 30, 190, 30);
  
  // Voucher title
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(0, 0, 0);
  doc.text('BOOKING VOUCHER', 105, 40, { align: 'center' });

  // Guest information section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text('GUEST INFORMATION', 20, 60);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  doc.text(`Name: ${booking.guest.firstName} ${booking.guest.lastName}`, 20, 70);
  doc.text(`Phone: ${booking.guest.phone}`, 20, 90);

  // Booking details section
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text('BOOKING DETAILS', 140, 60);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  
  const checkInDate = format(new Date(booking.booking.checkIn), 'MMMM dd, yyyy');
  const checkOutDate = format(new Date(booking.booking.checkOut), 'MMMM dd, yyyy');
  
  doc.text(`Check-in Date: ${checkInDate}`, 140, 70);
  doc.text(`Check-out Date: ${checkOutDate}`, 140, 78);
  doc.text(`Room Type: ${booking.booking.roomType}`, 140, 86);
  doc.text(`Number of Rooms: ${booking.booking.numberOfRooms}`, 140, 92);
  doc.text(`Guests: ${booking.booking.adults} Adult(s), ${booking.booking.children} Child(ren)`, 140, 98);
  doc.text(`Meal Plan: ${booking.booking.mealPlan}`, 140, 104);
  
  if (booking.booking.specialRequests) {
    doc.text('Special Requests:', 140, 110);
    const splitText = doc.splitTextToSize(booking.booking.specialRequests, 160);
    doc.text(splitText, 20, 172);
  }

  // Gold horizontal line
  doc.setDrawColor(212, 175, 55); // gold
  doc.setLineWidth(0.8);
  doc.line(20, 120, 190, 120);

  // Payment details (centered below line)
  const paymentY = 130;
  const tariff = parseFloat(booking.booking.tariff);
  const roomCharges = (tariff / 1.05).toFixed(2);
  const tax = (tariff - parseFloat(roomCharges)).toFixed(2);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text('PAYMENT DETAILS', 105, paymentY, { align: 'center' });

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);

  // Fixed payment details formatting
  doc.text(`Room Charges: ₹${roomCharges}`, 105, paymentY + 10, { align: 'center' });
  doc.text(`Tax: ₹${tax}`, 105, paymentY + 18, { align: 'center' });
  doc.text(`Tariff: ₹${booking.booking.tariff}`, 105, paymentY + 26, { align: 'center' });
  doc.text(`Advance: ₹${booking.booking.advance}`, 105, paymentY + 34, { align: 'center' });
  doc.text(`Payment Method: ${booking.booking.paymentMethod}`, 105, paymentY + 42, { align: 'center' });
  doc.text(`Status: ${booking.status.toUpperCase()}`, 105, paymentY + 50, { align: 'center' });

  // Hotel policies and footer
  doc.setFontSize(9);
  doc.setTextColor(100, 100, 100);
  doc.text('HOTEL POLICIES', 20, 230, { align: 'left' });

  doc.setFontSize(8);
  doc.text('Check-in time: 9:00 AM | Check-out time: 08:00 AM', 20, 237, { align: 'left' });
  doc.text('Please present this voucher and a valid ID at check-in.', 20, 242, { align: 'left' });
  doc.text('This booking is Non Refundable.', 20, 247, { align: 'left' });
  
  // Footer
  doc.setLineWidth(0.5);
  doc.line(20, 250, 190, 250);
  
  // Generate PDF blob
  return doc.output('blob');
}