import { Booking } from '../types/booking';
import { generateVoucher } from './generateVoucher';
import useBookingStore from '../store/bookingStore';
import { supabase } from './supabase';

export async function sendVoucher(booking: Booking): Promise<boolean> {
  try {
    const pdfBlob = await generateVoucher(booking);
    
    // Upload PDF to Supabase Storage
    const fileName = `vouchers/${booking.id}/${Date.now()}.pdf`;
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('vouchers')
      .upload(fileName, pdfBlob, {
        contentType: 'application/pdf',
        upsert: true
      });

    if (uploadError) throw uploadError;

    // Get public URL for the uploaded file
    const { data: { publicUrl } } = supabase.storage
      .from('vouchers')
      .getPublicUrl(fileName);

    // Store voucher reference in database
    const { error: dbError } = await supabase
      .from('vouchers')
      .insert({
        booking_id: booking.id,
        file_path: fileName
      });

    if (dbError) throw dbError;

    // Format phone number for WhatsApp
    let phoneNumber = booking.guest.phone.replace(/\D/g, '');
    if (!phoneNumber.startsWith('+')) {
      phoneNumber = '+' + phoneNumber;
    }

    // Create WhatsApp message with proper formatting
    const message = encodeURIComponent(
      `Dear ${booking.guest.firstName} ${booking.guest.lastName},\n\n` +
      `Thank you for choosing KAKKSON GROUP OF HOTELS!\n\n` +
      `*Booking Details:*\n` +
      `Check-in: ${new Date(booking.booking.checkIn).toLocaleDateString()}\n` +
      `Check-out: ${new Date(booking.booking.checkOut).toLocaleDateString()}\n` +
      `Room Type: ${booking.booking.roomType}\n\n` +
      `Your booking voucher is ready. Please click the link below to download:\n${publicUrl}\n\n` +
      `For any assistance, please contact our front desk.\n\n` +
      `Best regards,\nKAKKSON GROUP OF HOTELS`
    );
    
    // Open WhatsApp with the formatted message
    window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
    
    // Update store to mark voucher as sent
    const { setVoucherSent } = useBookingStore.getState();
    setVoucherSent(booking.id, true);
    
    return true;
  } catch (error) {
    console.error('Error sending voucher:', error);
    return false;
  }
}

export async function downloadVoucher(booking: Booking): Promise<void> {
  try {
    const pdfBlob = await generateVoucher(booking);
    const url = URL.createObjectURL(pdfBlob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `booking-voucher-${booking.id}.pdf`;
    document.body.appendChild(a);
    a.click();
    
    // Clean up
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error downloading voucher:', error);
  }
}